﻿Imports BarcodeLib

Public Class Form1
    Dim pallet_barcode As String
    Dim shellpart1 As String
    Dim shellpart2 As String
    Dim shellexecute As Integer
    Dim barcode As Barcode = New Barcode()
    Dim image As Image






    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        pallet_barcode = TextBox1.Text
        If My.Computer.FileSystem.FileExists("C:\test\testPDF.pdf") Then
            '"C:\Gebruikers\gwen\OneDrive - A.S. Watson Europe\Auxo - dump pdf files\" & pallet_barcode & ".pdf"
            ForeColor = Color.Black
            BackColor = Color.Red
            'shellexecute = Shell("C:\Gebruikers\gwen\OneDrive - A.S. Watson Europe\Auxo - dump pdf files\testPDF.pdf - Verb Print -PassThru",, True, 10)
            shellexecute = Shell("Start-Process -Filepath C:\test\testPDF.pdf",, True, 10)
            'Kill the open shell command
        Else

            MsgBox("No file found with the name matching: " & pallet_barcode & ".pdf, please check.")
            'image = barcode.Encode(TYPE.CODE128C, TextBox1.Text, Color.Black, Color.Red, 100, 100)
            'PictureBox1.Image = image

        End If



    End Sub

End Class